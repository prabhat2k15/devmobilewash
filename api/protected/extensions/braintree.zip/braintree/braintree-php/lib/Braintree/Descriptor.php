<?php
namespace Braintree;

class Descriptor extends Instance
{
}
class_alias('Braintree\Descriptor', 'Braintree_Descriptor');

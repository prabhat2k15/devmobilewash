<html>
<head>


</head>
<body style='margin: 0; padding: 0;'>
<div style='background: #c6c6c6; width: 100%; height: 100%; padding-top: 50px;'>
<div style='width: 650px; background: #fff; margin: 0 auto;'>
<div style='padding: 20px; text-align: center;'>
<a href='https://www.mobilewash.com'><img style='float: left;' src='https://www.mobilewash.com/images/logo-new.png' width='320' /></a>
<div style='float: right; margin-top: 30px;'>
                <a href='https://www.facebook.com/getmobilewash/'><img style='margin-left: 2px;' src='https://www.mobilewash.com/images/fb.png' alt=''></a>
               <a href='https://twitter.com/getmobilewash'><img style='margin-left: 2px;' src='https://www.mobilewash.com/images/tw.png' alt=''></a>
               <a href='https://plus.google.com/114985712775567009759/about'><img style='margin-left: 2px;' src='https://www.mobilewash.com/images/gp.png' alt=''></a>
                <a href='https://www.instagram.com/getmobilewash/'><img style='margin-left: 2px;' src='https://www.mobilewash.com/images/ins.png' alt=''></a>
                </div>
                <div style='clear: both;'></div>
                </div>
                <div style='background: #fff; padding: 20px; font-size: 16px; font-family: arial, sans-serif; line-height: 24px;'>
               <?php echo $content; ?>
                </div>

</div>
<p style='text-align: center; font-size: 14px; font-family: arial, sans-serif; line-height: 20px; margin-bottom: 0;'><a href="#">Unsubscribe</a></p>
<p style='text-align: center; font-size: 14px; font-family: arial, sans-serif; line-height: 20px; max-width: 480px; margin: 12px auto; padding-bottom: 25px;'>&copy; 2016 MobileWash, Inc. All rights reserved. All trademarks referenced herein are the property of their respective owners.</p>
</div>
</body>
</html>
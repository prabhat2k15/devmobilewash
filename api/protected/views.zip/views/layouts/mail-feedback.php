<html>
<head>

 
</head>
<body style='margin: 0; padding: 0;'>
<div style='background: #c6c6c6; width: 100%; height: 100%; padding-top: 50px;'>
<div style='width: 650px; background: #fff; margin: 0 auto;'>
<div style='padding: 20px; text-align: center;'>
<a href='https://www.mobilewash.com'><img style='display: block; margin: 0 auto;' src='https://www.mobilewash.com/images/logo-new.png' width='320' /></a>
                </div>
                <div style='background: #fff; padding: 20px; font-size: 16px; font-family: arial, sans-serif; line-height: 26px;'>
               <?php echo $content; ?>
                </div>
</div>
<p style='text-align: center; font-size: 16px; font-family: arial, sans-serif; line-height: 20px; margin: 12px auto; padding-bottom: 25px; margin-top: 20px;'>Thanks for choosing MobileWash.</p>
</div>
<p style='text-align: center; font-size: 14px; font-family: arial, sans-serif; line-height: 20px; max-width: 480px; margin: 12px auto; padding-bottom: 25px;'>&copy; <?php echo date("Y"); ?> MobileWash, Inc. All rights reserved. All trademarks referenced herein are the property of their respective owners.</p>

</body>
</html>
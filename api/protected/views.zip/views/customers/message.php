<center>
	<h1>
		<?php echo $message ?>
	</h1>
</center>
